<?php
/**
 * No content template.
 *
 * @package Pinster
 */
?>
<section class="pinster-no-results">
	<p><?php esc_html_e( 'Nothing found.', 'pinster' ); ?></p>
</section>
